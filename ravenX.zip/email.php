<?php
$emailku = 'sher12099@gmail.com'; // GANTI EMAIL KAMU DISINI
?>